#pragma once

class farmSequence
{
public:
	void init();

	void tick();
};

extern farmSequence g_sequence;
